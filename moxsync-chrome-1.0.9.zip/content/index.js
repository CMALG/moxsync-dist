"use strict";
(() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __commonJS = (cb, mod) => function __require() {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));

  // node_modules/webextension-polyfill/dist/browser-polyfill.js
  var require_browser_polyfill = __commonJS({
    "node_modules/webextension-polyfill/dist/browser-polyfill.js"(exports, module) {
      (function(global, factory) {
        if (typeof define === "function" && define.amd) {
          define("webextension-polyfill", ["module"], factory);
        } else if (typeof exports !== "undefined") {
          factory(module);
        } else {
          var mod = {
            exports: {}
          };
          factory(mod);
          global.browser = mod.exports;
        }
      })(typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : exports, function(module2) {
        "use strict";
        if (!(globalThis.chrome && globalThis.chrome.runtime && globalThis.chrome.runtime.id)) {
          throw new Error("This script should only be loaded in a browser extension.");
        }
        if (!(globalThis.browser && globalThis.browser.runtime && globalThis.browser.runtime.id)) {
          const CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE = "The message port closed before a response was received.";
          const wrapAPIs = (extensionAPIs) => {
            const apiMetadata = {
              "alarms": {
                "clear": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "clearAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "get": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "bookmarks": {
                "create": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getChildren": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getRecent": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getSubTree": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTree": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "move": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeTree": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "browserAction": {
                "disable": {
                  "minArgs": 0,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "enable": {
                  "minArgs": 0,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "getBadgeBackgroundColor": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getBadgeText": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getPopup": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTitle": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "openPopup": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "setBadgeBackgroundColor": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setBadgeText": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setIcon": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "setPopup": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setTitle": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "browsingData": {
                "remove": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "removeCache": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeCookies": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeDownloads": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeFormData": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeHistory": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeLocalStorage": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removePasswords": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removePluginData": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "settings": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "commands": {
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "contextMenus": {
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "cookies": {
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAllCookieStores": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "set": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "devtools": {
                "inspectedWindow": {
                  "eval": {
                    "minArgs": 1,
                    "maxArgs": 2,
                    "singleCallbackArg": false
                  }
                },
                "panels": {
                  "create": {
                    "minArgs": 3,
                    "maxArgs": 3,
                    "singleCallbackArg": true
                  },
                  "elements": {
                    "createSidebarPane": {
                      "minArgs": 1,
                      "maxArgs": 1
                    }
                  }
                }
              },
              "downloads": {
                "cancel": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "download": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "erase": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getFileIcon": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "open": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "pause": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeFile": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "resume": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "show": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "extension": {
                "isAllowedFileSchemeAccess": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "isAllowedIncognitoAccess": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "history": {
                "addUrl": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "deleteAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "deleteRange": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "deleteUrl": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getVisits": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "i18n": {
                "detectLanguage": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAcceptLanguages": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "identity": {
                "launchWebAuthFlow": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "idle": {
                "queryState": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "management": {
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getSelf": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "setEnabled": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "uninstallSelf": {
                  "minArgs": 0,
                  "maxArgs": 1
                }
              },
              "notifications": {
                "clear": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "create": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getPermissionLevel": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "pageAction": {
                "getPopup": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTitle": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "hide": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setIcon": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "setPopup": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setTitle": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "show": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "permissions": {
                "contains": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "request": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "runtime": {
                "getBackgroundPage": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getPlatformInfo": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "openOptionsPage": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "requestUpdateCheck": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "sendMessage": {
                  "minArgs": 1,
                  "maxArgs": 3
                },
                "sendNativeMessage": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "setUninstallURL": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "sessions": {
                "getDevices": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getRecentlyClosed": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "restore": {
                  "minArgs": 0,
                  "maxArgs": 1
                }
              },
              "storage": {
                "local": {
                  "clear": {
                    "minArgs": 0,
                    "maxArgs": 0
                  },
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "remove": {
                    "minArgs": 1,
                    "maxArgs": 1
                  },
                  "set": {
                    "minArgs": 1,
                    "maxArgs": 1
                  }
                },
                "managed": {
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  }
                },
                "sync": {
                  "clear": {
                    "minArgs": 0,
                    "maxArgs": 0
                  },
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "remove": {
                    "minArgs": 1,
                    "maxArgs": 1
                  },
                  "set": {
                    "minArgs": 1,
                    "maxArgs": 1
                  }
                }
              },
              "tabs": {
                "captureVisibleTab": {
                  "minArgs": 0,
                  "maxArgs": 2
                },
                "create": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "detectLanguage": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "discard": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "duplicate": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "executeScript": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getCurrent": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getZoom": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getZoomSettings": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "goBack": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "goForward": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "highlight": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "insertCSS": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "move": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "query": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "reload": {
                  "minArgs": 0,
                  "maxArgs": 2
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeCSS": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "sendMessage": {
                  "minArgs": 2,
                  "maxArgs": 3
                },
                "setZoom": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "setZoomSettings": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "update": {
                  "minArgs": 1,
                  "maxArgs": 2
                }
              },
              "topSites": {
                "get": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "webNavigation": {
                "getAllFrames": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getFrame": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "webRequest": {
                "handlerBehaviorChanged": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "windows": {
                "create": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getCurrent": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getLastFocused": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              }
            };
            if (Object.keys(apiMetadata).length === 0) {
              throw new Error("api-metadata.json has not been included in browser-polyfill");
            }
            class DefaultWeakMap extends WeakMap {
              constructor(createItem, items = void 0) {
                super(items);
                this.createItem = createItem;
              }
              get(key) {
                if (!this.has(key)) {
                  this.set(key, this.createItem(key));
                }
                return super.get(key);
              }
            }
            const isThenable = (value) => {
              return value && typeof value === "object" && typeof value.then === "function";
            };
            const makeCallback = (promise, metadata) => {
              return (...callbackArgs) => {
                if (extensionAPIs.runtime.lastError) {
                  promise.reject(new Error(extensionAPIs.runtime.lastError.message));
                } else if (metadata.singleCallbackArg || callbackArgs.length <= 1 && metadata.singleCallbackArg !== false) {
                  promise.resolve(callbackArgs[0]);
                } else {
                  promise.resolve(callbackArgs);
                }
              };
            };
            const pluralizeArguments = (numArgs) => numArgs == 1 ? "argument" : "arguments";
            const wrapAsyncFunction = (name, metadata) => {
              return function asyncFunctionWrapper(target, ...args) {
                if (args.length < metadata.minArgs) {
                  throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
                }
                if (args.length > metadata.maxArgs) {
                  throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
                }
                return new Promise((resolve, reject) => {
                  if (metadata.fallbackToNoCallback) {
                    try {
                      target[name](...args, makeCallback({
                        resolve,
                        reject
                      }, metadata));
                    } catch (cbError) {
                      console.warn(`${name} API method doesn't seem to support the callback parameter, falling back to call it without a callback: `, cbError);
                      target[name](...args);
                      metadata.fallbackToNoCallback = false;
                      metadata.noCallback = true;
                      resolve();
                    }
                  } else if (metadata.noCallback) {
                    target[name](...args);
                    resolve();
                  } else {
                    target[name](...args, makeCallback({
                      resolve,
                      reject
                    }, metadata));
                  }
                });
              };
            };
            const wrapMethod = (target, method, wrapper) => {
              return new Proxy(method, {
                apply(targetMethod, thisObj, args) {
                  return wrapper.call(thisObj, target, ...args);
                }
              });
            };
            let hasOwnProperty = Function.call.bind(Object.prototype.hasOwnProperty);
            const wrapObject = (target, wrappers = {}, metadata = {}) => {
              let cache = /* @__PURE__ */ Object.create(null);
              let handlers = {
                has(proxyTarget2, prop) {
                  return prop in target || prop in cache;
                },
                get(proxyTarget2, prop, receiver) {
                  if (prop in cache) {
                    return cache[prop];
                  }
                  if (!(prop in target)) {
                    return void 0;
                  }
                  let value = target[prop];
                  if (typeof value === "function") {
                    if (typeof wrappers[prop] === "function") {
                      value = wrapMethod(target, target[prop], wrappers[prop]);
                    } else if (hasOwnProperty(metadata, prop)) {
                      let wrapper = wrapAsyncFunction(prop, metadata[prop]);
                      value = wrapMethod(target, target[prop], wrapper);
                    } else {
                      value = value.bind(target);
                    }
                  } else if (typeof value === "object" && value !== null && (hasOwnProperty(wrappers, prop) || hasOwnProperty(metadata, prop))) {
                    value = wrapObject(value, wrappers[prop], metadata[prop]);
                  } else if (hasOwnProperty(metadata, "*")) {
                    value = wrapObject(value, wrappers[prop], metadata["*"]);
                  } else {
                    Object.defineProperty(cache, prop, {
                      configurable: true,
                      enumerable: true,
                      get() {
                        return target[prop];
                      },
                      set(value2) {
                        target[prop] = value2;
                      }
                    });
                    return value;
                  }
                  cache[prop] = value;
                  return value;
                },
                set(proxyTarget2, prop, value, receiver) {
                  if (prop in cache) {
                    cache[prop] = value;
                  } else {
                    target[prop] = value;
                  }
                  return true;
                },
                defineProperty(proxyTarget2, prop, desc) {
                  return Reflect.defineProperty(cache, prop, desc);
                },
                deleteProperty(proxyTarget2, prop) {
                  return Reflect.deleteProperty(cache, prop);
                }
              };
              let proxyTarget = Object.create(target);
              return new Proxy(proxyTarget, handlers);
            };
            const wrapEvent = (wrapperMap) => ({
              addListener(target, listener, ...args) {
                target.addListener(wrapperMap.get(listener), ...args);
              },
              hasListener(target, listener) {
                return target.hasListener(wrapperMap.get(listener));
              },
              removeListener(target, listener) {
                target.removeListener(wrapperMap.get(listener));
              }
            });
            const onRequestFinishedWrappers = new DefaultWeakMap((listener) => {
              if (typeof listener !== "function") {
                return listener;
              }
              return function onRequestFinished(req) {
                const wrappedReq = wrapObject(req, {}, {
                  getContent: {
                    minArgs: 0,
                    maxArgs: 0
                  }
                });
                listener(wrappedReq);
              };
            });
            const onMessageWrappers = new DefaultWeakMap((listener) => {
              if (typeof listener !== "function") {
                return listener;
              }
              return function onMessage(message, sender, sendResponse) {
                let didCallSendResponse = false;
                let wrappedSendResponse;
                let sendResponsePromise = new Promise((resolve) => {
                  wrappedSendResponse = function(response) {
                    didCallSendResponse = true;
                    resolve(response);
                  };
                });
                let result;
                try {
                  result = listener(message, sender, wrappedSendResponse);
                } catch (err) {
                  result = Promise.reject(err);
                }
                const isResultThenable = result !== true && isThenable(result);
                if (result !== true && !isResultThenable && !didCallSendResponse) {
                  return false;
                }
                const sendPromisedResult = (promise) => {
                  promise.then((msg) => {
                    sendResponse(msg);
                  }, (error) => {
                    let message2;
                    if (error && (error instanceof Error || typeof error.message === "string")) {
                      message2 = error.message;
                    } else {
                      message2 = "An unexpected error occurred";
                    }
                    sendResponse({
                      __mozWebExtensionPolyfillReject__: true,
                      message: message2
                    });
                  }).catch((err) => {
                    console.error("Failed to send onMessage rejected reply", err);
                  });
                };
                if (isResultThenable) {
                  sendPromisedResult(result);
                } else {
                  sendPromisedResult(sendResponsePromise);
                }
                return true;
              };
            });
            const wrappedSendMessageCallback = ({
              reject,
              resolve
            }, reply) => {
              if (extensionAPIs.runtime.lastError) {
                if (extensionAPIs.runtime.lastError.message === CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE) {
                  resolve();
                } else {
                  reject(new Error(extensionAPIs.runtime.lastError.message));
                }
              } else if (reply && reply.__mozWebExtensionPolyfillReject__) {
                reject(new Error(reply.message));
              } else {
                resolve(reply);
              }
            };
            const wrappedSendMessage = (name, metadata, apiNamespaceObj, ...args) => {
              if (args.length < metadata.minArgs) {
                throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
              }
              if (args.length > metadata.maxArgs) {
                throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
              }
              return new Promise((resolve, reject) => {
                const wrappedCb = wrappedSendMessageCallback.bind(null, {
                  resolve,
                  reject
                });
                args.push(wrappedCb);
                apiNamespaceObj.sendMessage(...args);
              });
            };
            const staticWrappers = {
              devtools: {
                network: {
                  onRequestFinished: wrapEvent(onRequestFinishedWrappers)
                }
              },
              runtime: {
                onMessage: wrapEvent(onMessageWrappers),
                onMessageExternal: wrapEvent(onMessageWrappers),
                sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
                  minArgs: 1,
                  maxArgs: 3
                })
              },
              tabs: {
                sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
                  minArgs: 2,
                  maxArgs: 3
                })
              }
            };
            const settingMetadata = {
              clear: {
                minArgs: 1,
                maxArgs: 1
              },
              get: {
                minArgs: 1,
                maxArgs: 1
              },
              set: {
                minArgs: 1,
                maxArgs: 1
              }
            };
            apiMetadata.privacy = {
              network: {
                "*": settingMetadata
              },
              services: {
                "*": settingMetadata
              },
              websites: {
                "*": settingMetadata
              }
            };
            return wrapObject(extensionAPIs, staticWrappers, apiMetadata);
          };
          module2.exports = wrapAPIs(chrome);
        } else {
          module2.exports = globalThis.browser;
        }
      });
    }
  });

  // src/content/cardLookupIndex.ts
  var import_webextension_polyfill = __toESM(require_browser_polyfill(), 1);

  // src/utils/cardNameNormalizer.ts
  function normalize(cardName) {
    return cardName.trim().toLowerCase();
  }

  // src/utils/debugLogger.ts
  var DEBUG_MODE_KEY = "debug_mode";
  var MAX_LOG_ENTRIES = 500;
  var DEBUG_LOG_KEY = "debug_log";
  var debugEnabled = null;
  var _browser = null;
  var _browserChecked = false;
  async function getBrowser() {
    if (_browserChecked) {
      return _browser;
    }
    _browserChecked = true;
    try {
      const mod = await Promise.resolve().then(() => __toESM(require_browser_polyfill(), 1));
      const b = mod.default ?? mod;
      if (b && b.storage && b.storage.local) {
        _browser = b;
        if (b.storage.onChanged) {
          b.storage.onChanged.addListener((changes) => {
            if (changes[DEBUG_MODE_KEY]) {
              debugEnabled = changes[DEBUG_MODE_KEY].newValue === true;
            }
          });
        }
      }
    } catch {
      _browser = null;
    }
    return _browser;
  }
  async function isDebugMode() {
    if (debugEnabled !== null) {
      return debugEnabled;
    }
    const b = await getBrowser();
    if (!b) {
      return false;
    }
    const result = await b.storage.local.get(DEBUG_MODE_KEY);
    debugEnabled = result[DEBUG_MODE_KEY] === true;
    return debugEnabled;
  }
  async function debugLog(area, level, message, details) {
    const enabled = await isDebugMode();
    if (level === "error") {
      console.error(`[MoxSync:${area}] ${message}`, details ?? "");
    }
    if (!enabled) {
      return;
    }
    if (level === "info") {
      console.log(`[MoxSync:${area}] ${message}`, details ?? "");
    } else if (level === "warn") {
      console.warn(`[MoxSync:${area}] ${message}`, details ?? "");
    }
    const entry = {
      timestamp: Date.now(),
      area,
      level,
      message,
      details: sanitizeDetails(details)
    };
    const b = await getBrowser();
    if (!b) {
      return;
    }
    try {
      const result = await b.storage.local.get(DEBUG_LOG_KEY);
      const logs = Array.isArray(result[DEBUG_LOG_KEY]) ? result[DEBUG_LOG_KEY] : [];
      logs.push(entry);
      if (logs.length > MAX_LOG_ENTRIES) {
        logs.splice(0, logs.length - MAX_LOG_ENTRIES);
      }
      await b.storage.local.set({ [DEBUG_LOG_KEY]: logs });
    } catch {
    }
  }
  function sanitizeDetails(details) {
    if (details === void 0 || details === null) {
      return void 0;
    }
    try {
      const json = JSON.stringify(details);
      if (json.length > 2048) {
        return JSON.parse(json.substring(0, 2048) + '..."');
      }
      return JSON.parse(json);
    } catch {
      return String(details);
    }
  }

  // src/content/cardLookupIndex.ts
  var cardIndex = /* @__PURE__ */ new Map();
  async function buildIndex() {
    const newIndex = /* @__PURE__ */ new Map();
    let result;
    try {
      result = await import_webextension_polyfill.default.storage.local.get("tracked_collections");
    } catch (err) {
      void debugLog("storage", "error", "Failed to read tracked_collections from storage", {
        error: err instanceof Error ? err.message : String(err)
      });
      return;
    }
    const stored = result.tracked_collections;
    const tracked = Array.isArray(stored) ? stored : [];
    if (tracked.length === 0) {
      void debugLog("storage", "info", "Index rebuild: 0 collections, index cleared");
      cardIndex = newIndex;
      return;
    }
    const storageKeys = tracked.map((c) => `collection_cards_${c.id}`);
    let cardDataResult;
    try {
      cardDataResult = await import_webextension_polyfill.default.storage.local.get(storageKeys);
    } catch (err) {
      void debugLog("storage", "error", "Failed to read card data from storage", {
        error: err instanceof Error ? err.message : String(err)
      });
      return;
    }
    const idToName = /* @__PURE__ */ new Map();
    for (const collection of tracked) {
      idToName.set(collection.id, collection.name);
    }
    for (const key of storageKeys) {
      const stored2 = cardDataResult[key];
      if (!stored2 || !stored2.cards) {
        continue;
      }
      const collectionName = idToName.get(stored2.collectionId);
      if (!collectionName) {
        continue;
      }
      for (const card of stored2.cards) {
        const normalizedName = card.normalizedName;
        const match = {
          collectionName,
          quantity: card.quantity,
          setName: card.setName ?? "",
          collectorNumber: card.collectorNumber ?? "",
          finish: card.finish ?? "nonFoil"
        };
        const existing = newIndex.get(normalizedName);
        if (existing) {
          existing.push(match);
        } else {
          newIndex.set(normalizedName, [match]);
        }
      }
    }
    for (const matches of newIndex.values()) {
      matches.sort((a, b) => a.collectionName.localeCompare(b.collectionName));
    }
    cardIndex = newIndex;
    void debugLog("storage", "info", `Index rebuilt: ${newIndex.size} unique cards across ${tracked.length} collections`);
  }
  function lookupCard(cardName) {
    const normalizedName = normalize(cardName);
    return cardIndex.get(normalizedName) ?? [];
  }
  async function initIndex() {
    await buildIndex();
    import_webextension_polyfill.default.storage.onChanged.addListener(onStorageChanged);
  }
  var rebuildTimer = null;
  function onStorageChanged(changes) {
    const relevantChange = Object.keys(changes).some(
      (key) => key === "tracked_collections" || key.startsWith("collection_cards_")
    );
    if (!relevantChange) {
      return;
    }
    if (rebuildTimer !== null) {
      clearTimeout(rebuildTimer);
    }
    rebuildTimer = setTimeout(() => {
      rebuildTimer = null;
      void debugLog("storage", "info", "Storage changed, rebuilding card index");
      void buildIndex();
    }, 250);
  }

  // src/utils/collectionFetcher.ts
  var API_BASE = "https://api2.moxfield.com/v1/collections/search";
  var TIMEOUT_MS = 3e4;
  var PAGE_SIZE = 100;
  async function fetchCollection(collectionId, onProgress) {
    const allCards = [];
    let pageNumber = 1;
    let totalPages = 1;
    let totalResults = 0;
    try {
      do {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), TIMEOUT_MS);
        try {
          const url = `${API_BASE}/${collectionId}?sortType=cardName&sortDirection=ascending&pageNumber=${pageNumber}&pageSize=${PAGE_SIZE}`;
          await debugLog("fetch", "info", `Fetching page ${pageNumber}/${totalPages}`, { collectionId, url });
          const response = await fetch(url, {
            signal: controller.signal,
            credentials: "include",
            headers: {
              "Accept": "application/json, text/plain, */*",
              "x-moxfield-version": "2026.08.19.1"
            }
          });
          if (!response.ok) {
            await debugLog("fetch", "error", `HTTP error fetching collection`, {
              collectionId,
              status: response.status,
              statusText: response.statusText,
              pageNumber
            });
            return {
              success: false,
              error: `HTTP ${response.status}: ${response.statusText}`
            };
          }
          let data;
          try {
            data = await response.json();
          } catch {
            await debugLog("fetch", "error", "Failed to parse JSON response", { collectionId, pageNumber });
            return { success: false, error: "Could not parse collection data" };
          }
          const parsed = parsePage(data);
          if (!parsed) {
            await debugLog("fetch", "error", "Unexpected response format", { collectionId, pageNumber });
            return { success: false, error: "Unexpected response format" };
          }
          allCards.push(...parsed.cards);
          totalPages = parsed.totalPages;
          totalResults = parsed.totalResults;
          if (onProgress) {
            onProgress({
              pageNumber,
              totalPages,
              cardsFetched: allCards.length,
              totalResults
            });
          }
          pageNumber++;
        } finally {
          clearTimeout(timeoutId);
        }
      } while (pageNumber <= totalPages);
      return { success: true, cards: allCards };
    } catch (error) {
      if (error instanceof DOMException && error.name === "AbortError") {
        await debugLog("fetch", "error", "Request timed out", { collectionId, pageNumber });
        return { success: false, error: "Request timed out after 30 seconds" };
      }
      const message = error instanceof Error ? error.message : "Unknown network error";
      await debugLog("fetch", "error", `Network error: ${message}`, { collectionId, pageNumber });
      return { success: false, error: message };
    }
  }
  function parsePage(data) {
    if (data === null || typeof data !== "object") {
      return null;
    }
    const response = data;
    const totalPages = typeof response["totalPages"] === "number" ? response["totalPages"] : 0;
    const totalResults = typeof response["totalResults"] === "number" ? response["totalResults"] : 0;
    const dataArray = response["data"];
    if (!Array.isArray(dataArray)) {
      return null;
    }
    const cards = [];
    for (const entry of dataArray) {
      if (entry === null || typeof entry !== "object") {
        continue;
      }
      const entryObj = entry;
      const quantity = typeof entryObj["quantity"] === "number" ? entryObj["quantity"] : 0;
      const card = entryObj["card"];
      if (card === null || typeof card !== "object") {
        continue;
      }
      const cardObj = card;
      const name = typeof cardObj["name"] === "string" ? cardObj["name"] : "";
      const setName = typeof cardObj["set_name"] === "string" ? cardObj["set_name"] : "";
      const cn = typeof cardObj["cn"] === "string" ? cardObj["cn"] : "";
      const finish = typeof entryObj["finish"] === "string" ? entryObj["finish"] : "nonFoil";
      if (name && quantity > 0) {
        cards.push({ name, quantity, setName, collectorNumber: cn, finish });
      }
    }
    return { cards, totalPages, totalResults };
  }

  // src/content/index.ts
  var import_webextension_polyfill2 = __toESM(require_browser_polyfill(), 1);
  var INJECTED_MARKER = "data-moxsync-injected";
  var lastHoveredCardName = null;
  function setupHoverTracking() {
    document.addEventListener("mouseover", (event) => {
      const target = event.target;
      if (target.tagName === "IMG" && target.classList.contains("img-card")) {
        const alt = target.getAttribute("alt");
        if (alt) {
          lastHoveredCardName = alt;
          void debugLog("injection", "info", `Hover detected: "${alt}"`);
          return;
        }
      }
      const collectionLink = target.closest('a[id^="collection_"]');
      if (collectionLink) {
        const cardContainer = collectionLink.closest('[tabindex="0"]');
        if (cardContainer) {
          const img = cardContainer.querySelector("img.img-card");
          if (img && img.alt) {
            lastHoveredCardName = img.alt;
            void debugLog("injection", "info", `Hover via collection icon: "${img.alt}"`);
            return;
          }
        }
      }
      const name = findCardNameFromElement(target);
      if (name) {
        lastHoveredCardName = name;
      }
    });
  }
  function isCollectionTrackerTooltip(node) {
    if (!(node instanceof HTMLElement)) {
      return false;
    }
    if (node.getAttribute("data-testid") === "tooltip") {
      return true;
    }
    const className = node.className;
    if (typeof className === "string") {
      if (className.includes("tooltip") && className.includes("show")) {
        return true;
      }
    }
    return false;
  }
  function isCollectionTrackerContent(tooltipElement) {
    const text = tooltipElement.textContent ?? "";
    return text.includes("Collection Tracker");
  }
  function injectCollectionData(popupElement, matches) {
    if (popupElement.querySelector(`[${INJECTED_MARKER}]`)) {
      return;
    }
    void debugLog("injection", "info", `Injecting ${matches.length} matches into tooltip`);
    const tooltipInner = popupElement.querySelector(".tooltip-inner") ?? popupElement;
    const container = document.createElement("div");
    container.setAttribute(INJECTED_MARKER, "true");
    container.className = "text-start mb-2";
    container.style.borderTop = "1px solid rgba(255, 255, 255, 0.2)";
    container.style.marginTop = "8px";
    container.style.paddingTop = "8px";
    const header = document.createElement("div");
    header.className = "text-start small mb-2";
    const headerStrong = document.createElement("strong");
    headerStrong.className = "text-caps";
    headerStrong.textContent = "Tracked Collections";
    header.appendChild(headerStrong);
    container.appendChild(header);
    const table = document.createElement("table");
    table.className = "table table-xs table-borderless text-white small mb-0";
    const tbody = document.createElement("tbody");
    for (const match of matches) {
      const row = document.createElement("tr");
      const qtyCell = document.createElement("td");
      qtyCell.style.width = "22px";
      qtyCell.textContent = String(match.quantity);
      const setCell = document.createElement("td");
      setCell.textContent = match.setName;
      if (match.collectorNumber) {
        const numSpan = document.createElement("span");
        numSpan.className = "text-muted";
        numSpan.textContent = ` (#${match.collectorNumber})`;
        setCell.appendChild(numSpan);
      }
      const finishCell = document.createElement("td");
      finishCell.style.width = "60px";
      finishCell.textContent = match.finish === "nonFoil" ? "nonfoil" : match.finish;
      const ownerCell = document.createElement("td");
      ownerCell.style.width = "auto";
      ownerCell.className = "text-muted";
      ownerCell.textContent = match.collectionName;
      row.appendChild(qtyCell);
      row.appendChild(setCell);
      row.appendChild(finishCell);
      row.appendChild(ownerCell);
      tbody.appendChild(row);
    }
    table.appendChild(tbody);
    container.appendChild(table);
    tooltipInner.appendChild(container);
  }
  function resolveCardNameForTooltip(tooltipElement) {
    const tooltipId = tooltipElement.getAttribute("id");
    if (tooltipId) {
      const trigger = document.querySelector(
        `[aria-describedby~="${CSS.escape(tooltipId)}"]`
      );
      if (trigger) {
        const name = findCardNameFromElement(trigger);
        if (name) {
          void debugLog("injection", "info", `Resolved card via tooltip trigger: "${name}"`);
          return name;
        }
      }
    }
    const nameByPoint = resolveCardNameByPosition(tooltipElement);
    if (nameByPoint) {
      void debugLog("injection", "info", `Resolved card via tooltip position: "${nameByPoint}"`);
      return nameByPoint;
    }
    return lastHoveredCardName;
  }
  function resolveCardNameByPosition(tooltipElement) {
    const rect = tooltipElement.getBoundingClientRect();
    if (rect.width === 0 && rect.height === 0) {
      return null;
    }
    const arrow = tooltipElement.querySelector(".arrow");
    const cls = tooltipElement.className;
    const gap = 6;
    let probeX = rect.left + rect.width / 2;
    if (arrow) {
      const arrowLeft = parseFloat(arrow.style.left || "");
      if (!Number.isNaN(arrowLeft)) {
        probeX = rect.left + arrowLeft + arrow.offsetWidth / 2;
      }
    }
    let probeY = rect.top + rect.height / 2;
    const offsets = [gap, gap + 8, gap + 18, gap + 30];
    for (const off of offsets) {
      let px = probeX;
      let py = probeY;
      if (cls.includes("bs-tooltip-top")) {
        py = rect.bottom + off;
      } else if (cls.includes("bs-tooltip-bottom")) {
        py = rect.top - off;
      } else if (cls.includes("bs-tooltip-start") || cls.includes("bs-tooltip-left")) {
        px = rect.right + off;
        py = rect.top + rect.height / 2;
      } else if (cls.includes("bs-tooltip-end") || cls.includes("bs-tooltip-right")) {
        px = rect.left - off;
        py = rect.top + rect.height / 2;
      }
      const el = document.elementFromPoint(px, py);
      if (el instanceof HTMLElement) {
        const name = findCardNameFromElement(el);
        if (name) {
          return name;
        }
      }
    }
    return null;
  }
  function findCardNameFromElement(element) {
    const candidates = [
      element.closest("[data-card-name]"),
      element.closest('[tabindex="0"]'),
      element.closest(".decklist-card, .decklist-row, tr, li"),
      element.closest(".col-12.col-md"),
      element.parentElement
    ];
    for (const container of candidates) {
      if (!container) {
        continue;
      }
      const name = extractCardName(container);
      if (name) {
        return name;
      }
    }
    return null;
  }
  function extractCardName(container) {
    const dataName = container.getAttribute("data-card-name");
    if (dataName) {
      return dataName;
    }
    const img = container.querySelector("img.img-card");
    if (img && img.alt) {
      return img.alt;
    }
    const nameLink = container.querySelector(
      'h3 a[href*="/cards/"], a[href*="/cards/"], a[href*="/card/"]'
    );
    const linkText = nameLink?.textContent?.trim();
    if (linkText) {
      return linkText;
    }
    const nameSpan = container.querySelector(
      ".decklist-name, .phantom-search"
    );
    const spanText = nameSpan?.textContent?.trim();
    if (spanText) {
      return spanText;
    }
    return null;
  }
  function processTooltip(tooltipElement) {
    setTimeout(() => {
      if (!isCollectionTrackerContent(tooltipElement)) {
        return;
      }
      const cardName = resolveCardNameForTooltip(tooltipElement);
      if (!cardName) {
        void debugLog("injection", "warn", "No hovered card name available, skipping injection");
        return;
      }
      void debugLog("injection", "info", `Processing tooltip for card: "${cardName}"`);
      const matches = lookupCard(cardName);
      if (matches.length > 0) {
        injectCollectionData(tooltipElement, matches);
      } else {
        void debugLog("injection", "info", `No matches found for "${cardName}"`);
      }
    }, 50);
  }
  function handleMutations(mutations) {
    let hasNewNodes = false;
    for (const mutation of mutations) {
      if (mutation.type !== "childList") {
        continue;
      }
      for (const node of mutation.addedNodes) {
        if (isCollectionTrackerTooltip(node)) {
          processTooltip(node);
          continue;
        }
        if (node instanceof HTMLElement) {
          hasNewNodes = true;
          const tooltips = node.querySelectorAll(
            '[data-testid="tooltip"], .tooltip.show'
          );
          for (const tooltip of tooltips) {
            processTooltip(tooltip);
          }
        }
      }
    }
    if (hasNewNodes && window.location.pathname.includes("/search")) {
      injectIntoSearchResults();
    }
  }
  function injectIntoSearchResults() {
    const cardLinks = document.querySelectorAll('h3 a[href*="/cards/"]');
    let scanned = 0;
    let matched = 0;
    for (const link of cardLinks) {
      const cardName = link.textContent?.trim();
      if (!cardName) continue;
      scanned++;
      const resultContainer = link.closest(".col-12.col-md");
      if (!resultContainer) continue;
      if (resultContainer.querySelector(`[${INJECTED_MARKER}]`)) continue;
      const matches = lookupCard(cardName);
      if (matches.length === 0) continue;
      matched++;
      const infoSection = resultContainer.querySelector(".text-center.text-md-left");
      if (!infoSection) continue;
      const container = document.createElement("div");
      container.setAttribute(INJECTED_MARKER, "true");
      container.className = "mt-3";
      const alert = document.createElement("div");
      alert.className = "alert alert-success px-2 py-1 d-inline-block";
      alert.style.cssText = "font-size: 0.85rem; color: #155724 !important; background-color: #d4edda !important; border-color: #c3e6cb !important;";
      const header = document.createElement("div");
      header.className = "mb-1";
      header.style.cssText = "color: #155724 !important;";
      const headerStrong = document.createElement("strong");
      headerStrong.textContent = "Found in Tracked Collections:";
      header.appendChild(headerStrong);
      alert.appendChild(header);
      const table = document.createElement("table");
      table.className = "table table-xs table-borderless small mb-0";
      table.style.cssText = "color: #155724 !important;";
      const tbody = document.createElement("tbody");
      for (const match of matches) {
        const row = document.createElement("tr");
        const qtyCell = document.createElement("td");
        qtyCell.style.cssText = "width: 22px; color: #155724 !important;";
        qtyCell.textContent = String(match.quantity);
        const setCell = document.createElement("td");
        setCell.style.cssText = "color: #155724 !important;";
        setCell.textContent = match.setName;
        if (match.collectorNumber) {
          const numSpan = document.createElement("span");
          numSpan.style.cssText = "color: #6c757d !important;";
          numSpan.textContent = ` (#${match.collectorNumber})`;
          setCell.appendChild(numSpan);
        }
        const finishCell = document.createElement("td");
        finishCell.style.cssText = "width: 60px; color: #155724 !important;";
        finishCell.textContent = match.finish === "nonFoil" ? "nonfoil" : match.finish;
        const ownerCell = document.createElement("td");
        ownerCell.style.cssText = "color: #6c757d !important;";
        ownerCell.textContent = match.collectionName;
        row.appendChild(qtyCell);
        row.appendChild(setCell);
        row.appendChild(finishCell);
        row.appendChild(ownerCell);
        tbody.appendChild(row);
      }
      table.appendChild(tbody);
      alert.appendChild(table);
      container.appendChild(alert);
      infoSection.appendChild(container);
    }
    if (scanned > 0) {
      void debugLog("injection", "info", `Search results: scanned ${scanned} cards, ${matched} matched tracked collections`);
    }
  }
  function setupSearchPageInjection() {
    if (window.location.pathname.includes("/search")) {
      setTimeout(injectIntoSearchResults, 500);
    }
  }
  var observer = null;
  async function init() {
    void debugLog("injection", "info", "Content script initializing");
    await initIndex();
    setupHoverTracking();
    setupSearchPageInjection();
    observer = new MutationObserver(handleMutations);
    observer.observe(document.body, {
      childList: true,
      subtree: true
    });
    void debugLog("injection", "info", "Content script initialized, MutationObserver active");
  }
  function destroy() {
    if (observer) {
      observer.disconnect();
      observer = null;
    }
  }
  import_webextension_polyfill2.default.runtime.onMessage.addListener(
    (message) => {
      const msg = message;
      if (msg.type === "FETCH_COLLECTION" && msg.collectionId) {
        return fetchCollection(msg.collectionId, (progress) => {
          import_webextension_polyfill2.default.runtime.sendMessage({
            type: "FETCH_PROGRESS",
            collectionId: msg.collectionId,
            progress
          }).catch(() => {
          });
        });
      }
      return void 0;
    }
  );
  void init();
})();
