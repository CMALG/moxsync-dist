var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// node_modules/webextension-polyfill/dist/browser-polyfill.js
var require_browser_polyfill = __commonJS({
  "node_modules/webextension-polyfill/dist/browser-polyfill.js"(exports, module) {
    (function(global, factory) {
      if (typeof define === "function" && define.amd) {
        define("webextension-polyfill", ["module"], factory);
      } else if (typeof exports !== "undefined") {
        factory(module);
      } else {
        var mod = {
          exports: {}
        };
        factory(mod);
        global.browser = mod.exports;
      }
    })(typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : exports, function(module2) {
      "use strict";
      if (!(globalThis.chrome && globalThis.chrome.runtime && globalThis.chrome.runtime.id)) {
        throw new Error("This script should only be loaded in a browser extension.");
      }
      if (!(globalThis.browser && globalThis.browser.runtime && globalThis.browser.runtime.id)) {
        const CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE = "The message port closed before a response was received.";
        const wrapAPIs = (extensionAPIs) => {
          const apiMetadata = {
            "alarms": {
              "clear": {
                "minArgs": 0,
                "maxArgs": 1
              },
              "clearAll": {
                "minArgs": 0,
                "maxArgs": 0
              },
              "get": {
                "minArgs": 0,
                "maxArgs": 1
              },
              "getAll": {
                "minArgs": 0,
                "maxArgs": 0
              }
            },
            "bookmarks": {
              "create": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "get": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "getChildren": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "getRecent": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "getSubTree": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "getTree": {
                "minArgs": 0,
                "maxArgs": 0
              },
              "move": {
                "minArgs": 2,
                "maxArgs": 2
              },
              "remove": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "removeTree": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "search": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "update": {
                "minArgs": 2,
                "maxArgs": 2
              }
            },
            "browserAction": {
              "disable": {
                "minArgs": 0,
                "maxArgs": 1,
                "fallbackToNoCallback": true
              },
              "enable": {
                "minArgs": 0,
                "maxArgs": 1,
                "fallbackToNoCallback": true
              },
              "getBadgeBackgroundColor": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "getBadgeText": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "getPopup": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "getTitle": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "openPopup": {
                "minArgs": 0,
                "maxArgs": 0
              },
              "setBadgeBackgroundColor": {
                "minArgs": 1,
                "maxArgs": 1,
                "fallbackToNoCallback": true
              },
              "setBadgeText": {
                "minArgs": 1,
                "maxArgs": 1,
                "fallbackToNoCallback": true
              },
              "setIcon": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "setPopup": {
                "minArgs": 1,
                "maxArgs": 1,
                "fallbackToNoCallback": true
              },
              "setTitle": {
                "minArgs": 1,
                "maxArgs": 1,
                "fallbackToNoCallback": true
              }
            },
            "browsingData": {
              "remove": {
                "minArgs": 2,
                "maxArgs": 2
              },
              "removeCache": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "removeCookies": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "removeDownloads": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "removeFormData": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "removeHistory": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "removeLocalStorage": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "removePasswords": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "removePluginData": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "settings": {
                "minArgs": 0,
                "maxArgs": 0
              }
            },
            "commands": {
              "getAll": {
                "minArgs": 0,
                "maxArgs": 0
              }
            },
            "contextMenus": {
              "remove": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "removeAll": {
                "minArgs": 0,
                "maxArgs": 0
              },
              "update": {
                "minArgs": 2,
                "maxArgs": 2
              }
            },
            "cookies": {
              "get": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "getAll": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "getAllCookieStores": {
                "minArgs": 0,
                "maxArgs": 0
              },
              "remove": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "set": {
                "minArgs": 1,
                "maxArgs": 1
              }
            },
            "devtools": {
              "inspectedWindow": {
                "eval": {
                  "minArgs": 1,
                  "maxArgs": 2,
                  "singleCallbackArg": false
                }
              },
              "panels": {
                "create": {
                  "minArgs": 3,
                  "maxArgs": 3,
                  "singleCallbackArg": true
                },
                "elements": {
                  "createSidebarPane": {
                    "minArgs": 1,
                    "maxArgs": 1
                  }
                }
              }
            },
            "downloads": {
              "cancel": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "download": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "erase": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "getFileIcon": {
                "minArgs": 1,
                "maxArgs": 2
              },
              "open": {
                "minArgs": 1,
                "maxArgs": 1,
                "fallbackToNoCallback": true
              },
              "pause": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "removeFile": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "resume": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "search": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "show": {
                "minArgs": 1,
                "maxArgs": 1,
                "fallbackToNoCallback": true
              }
            },
            "extension": {
              "isAllowedFileSchemeAccess": {
                "minArgs": 0,
                "maxArgs": 0
              },
              "isAllowedIncognitoAccess": {
                "minArgs": 0,
                "maxArgs": 0
              }
            },
            "history": {
              "addUrl": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "deleteAll": {
                "minArgs": 0,
                "maxArgs": 0
              },
              "deleteRange": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "deleteUrl": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "getVisits": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "search": {
                "minArgs": 1,
                "maxArgs": 1
              }
            },
            "i18n": {
              "detectLanguage": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "getAcceptLanguages": {
                "minArgs": 0,
                "maxArgs": 0
              }
            },
            "identity": {
              "launchWebAuthFlow": {
                "minArgs": 1,
                "maxArgs": 1
              }
            },
            "idle": {
              "queryState": {
                "minArgs": 1,
                "maxArgs": 1
              }
            },
            "management": {
              "get": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "getAll": {
                "minArgs": 0,
                "maxArgs": 0
              },
              "getSelf": {
                "minArgs": 0,
                "maxArgs": 0
              },
              "setEnabled": {
                "minArgs": 2,
                "maxArgs": 2
              },
              "uninstallSelf": {
                "minArgs": 0,
                "maxArgs": 1
              }
            },
            "notifications": {
              "clear": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "create": {
                "minArgs": 1,
                "maxArgs": 2
              },
              "getAll": {
                "minArgs": 0,
                "maxArgs": 0
              },
              "getPermissionLevel": {
                "minArgs": 0,
                "maxArgs": 0
              },
              "update": {
                "minArgs": 2,
                "maxArgs": 2
              }
            },
            "pageAction": {
              "getPopup": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "getTitle": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "hide": {
                "minArgs": 1,
                "maxArgs": 1,
                "fallbackToNoCallback": true
              },
              "setIcon": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "setPopup": {
                "minArgs": 1,
                "maxArgs": 1,
                "fallbackToNoCallback": true
              },
              "setTitle": {
                "minArgs": 1,
                "maxArgs": 1,
                "fallbackToNoCallback": true
              },
              "show": {
                "minArgs": 1,
                "maxArgs": 1,
                "fallbackToNoCallback": true
              }
            },
            "permissions": {
              "contains": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "getAll": {
                "minArgs": 0,
                "maxArgs": 0
              },
              "remove": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "request": {
                "minArgs": 1,
                "maxArgs": 1
              }
            },
            "runtime": {
              "getBackgroundPage": {
                "minArgs": 0,
                "maxArgs": 0
              },
              "getPlatformInfo": {
                "minArgs": 0,
                "maxArgs": 0
              },
              "openOptionsPage": {
                "minArgs": 0,
                "maxArgs": 0
              },
              "requestUpdateCheck": {
                "minArgs": 0,
                "maxArgs": 0
              },
              "sendMessage": {
                "minArgs": 1,
                "maxArgs": 3
              },
              "sendNativeMessage": {
                "minArgs": 2,
                "maxArgs": 2
              },
              "setUninstallURL": {
                "minArgs": 1,
                "maxArgs": 1
              }
            },
            "sessions": {
              "getDevices": {
                "minArgs": 0,
                "maxArgs": 1
              },
              "getRecentlyClosed": {
                "minArgs": 0,
                "maxArgs": 1
              },
              "restore": {
                "minArgs": 0,
                "maxArgs": 1
              }
            },
            "storage": {
              "local": {
                "clear": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "get": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getBytesInUse": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "set": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "managed": {
                "get": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getBytesInUse": {
                  "minArgs": 0,
                  "maxArgs": 1
                }
              },
              "sync": {
                "clear": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "get": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getBytesInUse": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "set": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              }
            },
            "tabs": {
              "captureVisibleTab": {
                "minArgs": 0,
                "maxArgs": 2
              },
              "create": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "detectLanguage": {
                "minArgs": 0,
                "maxArgs": 1
              },
              "discard": {
                "minArgs": 0,
                "maxArgs": 1
              },
              "duplicate": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "executeScript": {
                "minArgs": 1,
                "maxArgs": 2
              },
              "get": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "getCurrent": {
                "minArgs": 0,
                "maxArgs": 0
              },
              "getZoom": {
                "minArgs": 0,
                "maxArgs": 1
              },
              "getZoomSettings": {
                "minArgs": 0,
                "maxArgs": 1
              },
              "goBack": {
                "minArgs": 0,
                "maxArgs": 1
              },
              "goForward": {
                "minArgs": 0,
                "maxArgs": 1
              },
              "highlight": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "insertCSS": {
                "minArgs": 1,
                "maxArgs": 2
              },
              "move": {
                "minArgs": 2,
                "maxArgs": 2
              },
              "query": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "reload": {
                "minArgs": 0,
                "maxArgs": 2
              },
              "remove": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "removeCSS": {
                "minArgs": 1,
                "maxArgs": 2
              },
              "sendMessage": {
                "minArgs": 2,
                "maxArgs": 3
              },
              "setZoom": {
                "minArgs": 1,
                "maxArgs": 2
              },
              "setZoomSettings": {
                "minArgs": 1,
                "maxArgs": 2
              },
              "update": {
                "minArgs": 1,
                "maxArgs": 2
              }
            },
            "topSites": {
              "get": {
                "minArgs": 0,
                "maxArgs": 0
              }
            },
            "webNavigation": {
              "getAllFrames": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "getFrame": {
                "minArgs": 1,
                "maxArgs": 1
              }
            },
            "webRequest": {
              "handlerBehaviorChanged": {
                "minArgs": 0,
                "maxArgs": 0
              }
            },
            "windows": {
              "create": {
                "minArgs": 0,
                "maxArgs": 1
              },
              "get": {
                "minArgs": 1,
                "maxArgs": 2
              },
              "getAll": {
                "minArgs": 0,
                "maxArgs": 1
              },
              "getCurrent": {
                "minArgs": 0,
                "maxArgs": 1
              },
              "getLastFocused": {
                "minArgs": 0,
                "maxArgs": 1
              },
              "remove": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "update": {
                "minArgs": 2,
                "maxArgs": 2
              }
            }
          };
          if (Object.keys(apiMetadata).length === 0) {
            throw new Error("api-metadata.json has not been included in browser-polyfill");
          }
          class DefaultWeakMap extends WeakMap {
            constructor(createItem, items = void 0) {
              super(items);
              this.createItem = createItem;
            }
            get(key) {
              if (!this.has(key)) {
                this.set(key, this.createItem(key));
              }
              return super.get(key);
            }
          }
          const isThenable = (value) => {
            return value && typeof value === "object" && typeof value.then === "function";
          };
          const makeCallback = (promise, metadata) => {
            return (...callbackArgs) => {
              if (extensionAPIs.runtime.lastError) {
                promise.reject(new Error(extensionAPIs.runtime.lastError.message));
              } else if (metadata.singleCallbackArg || callbackArgs.length <= 1 && metadata.singleCallbackArg !== false) {
                promise.resolve(callbackArgs[0]);
              } else {
                promise.resolve(callbackArgs);
              }
            };
          };
          const pluralizeArguments = (numArgs) => numArgs == 1 ? "argument" : "arguments";
          const wrapAsyncFunction = (name, metadata) => {
            return function asyncFunctionWrapper(target, ...args) {
              if (args.length < metadata.minArgs) {
                throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
              }
              if (args.length > metadata.maxArgs) {
                throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
              }
              return new Promise((resolve, reject) => {
                if (metadata.fallbackToNoCallback) {
                  try {
                    target[name](...args, makeCallback({
                      resolve,
                      reject
                    }, metadata));
                  } catch (cbError) {
                    console.warn(`${name} API method doesn't seem to support the callback parameter, falling back to call it without a callback: `, cbError);
                    target[name](...args);
                    metadata.fallbackToNoCallback = false;
                    metadata.noCallback = true;
                    resolve();
                  }
                } else if (metadata.noCallback) {
                  target[name](...args);
                  resolve();
                } else {
                  target[name](...args, makeCallback({
                    resolve,
                    reject
                  }, metadata));
                }
              });
            };
          };
          const wrapMethod = (target, method, wrapper) => {
            return new Proxy(method, {
              apply(targetMethod, thisObj, args) {
                return wrapper.call(thisObj, target, ...args);
              }
            });
          };
          let hasOwnProperty = Function.call.bind(Object.prototype.hasOwnProperty);
          const wrapObject = (target, wrappers = {}, metadata = {}) => {
            let cache = /* @__PURE__ */ Object.create(null);
            let handlers = {
              has(proxyTarget2, prop) {
                return prop in target || prop in cache;
              },
              get(proxyTarget2, prop, receiver) {
                if (prop in cache) {
                  return cache[prop];
                }
                if (!(prop in target)) {
                  return void 0;
                }
                let value = target[prop];
                if (typeof value === "function") {
                  if (typeof wrappers[prop] === "function") {
                    value = wrapMethod(target, target[prop], wrappers[prop]);
                  } else if (hasOwnProperty(metadata, prop)) {
                    let wrapper = wrapAsyncFunction(prop, metadata[prop]);
                    value = wrapMethod(target, target[prop], wrapper);
                  } else {
                    value = value.bind(target);
                  }
                } else if (typeof value === "object" && value !== null && (hasOwnProperty(wrappers, prop) || hasOwnProperty(metadata, prop))) {
                  value = wrapObject(value, wrappers[prop], metadata[prop]);
                } else if (hasOwnProperty(metadata, "*")) {
                  value = wrapObject(value, wrappers[prop], metadata["*"]);
                } else {
                  Object.defineProperty(cache, prop, {
                    configurable: true,
                    enumerable: true,
                    get() {
                      return target[prop];
                    },
                    set(value2) {
                      target[prop] = value2;
                    }
                  });
                  return value;
                }
                cache[prop] = value;
                return value;
              },
              set(proxyTarget2, prop, value, receiver) {
                if (prop in cache) {
                  cache[prop] = value;
                } else {
                  target[prop] = value;
                }
                return true;
              },
              defineProperty(proxyTarget2, prop, desc) {
                return Reflect.defineProperty(cache, prop, desc);
              },
              deleteProperty(proxyTarget2, prop) {
                return Reflect.deleteProperty(cache, prop);
              }
            };
            let proxyTarget = Object.create(target);
            return new Proxy(proxyTarget, handlers);
          };
          const wrapEvent = (wrapperMap) => ({
            addListener(target, listener, ...args) {
              target.addListener(wrapperMap.get(listener), ...args);
            },
            hasListener(target, listener) {
              return target.hasListener(wrapperMap.get(listener));
            },
            removeListener(target, listener) {
              target.removeListener(wrapperMap.get(listener));
            }
          });
          const onRequestFinishedWrappers = new DefaultWeakMap((listener) => {
            if (typeof listener !== "function") {
              return listener;
            }
            return function onRequestFinished(req) {
              const wrappedReq = wrapObject(req, {}, {
                getContent: {
                  minArgs: 0,
                  maxArgs: 0
                }
              });
              listener(wrappedReq);
            };
          });
          const onMessageWrappers = new DefaultWeakMap((listener) => {
            if (typeof listener !== "function") {
              return listener;
            }
            return function onMessage(message, sender, sendResponse) {
              let didCallSendResponse = false;
              let wrappedSendResponse;
              let sendResponsePromise = new Promise((resolve) => {
                wrappedSendResponse = function(response) {
                  didCallSendResponse = true;
                  resolve(response);
                };
              });
              let result;
              try {
                result = listener(message, sender, wrappedSendResponse);
              } catch (err) {
                result = Promise.reject(err);
              }
              const isResultThenable = result !== true && isThenable(result);
              if (result !== true && !isResultThenable && !didCallSendResponse) {
                return false;
              }
              const sendPromisedResult = (promise) => {
                promise.then((msg) => {
                  sendResponse(msg);
                }, (error) => {
                  let message2;
                  if (error && (error instanceof Error || typeof error.message === "string")) {
                    message2 = error.message;
                  } else {
                    message2 = "An unexpected error occurred";
                  }
                  sendResponse({
                    __mozWebExtensionPolyfillReject__: true,
                    message: message2
                  });
                }).catch((err) => {
                  console.error("Failed to send onMessage rejected reply", err);
                });
              };
              if (isResultThenable) {
                sendPromisedResult(result);
              } else {
                sendPromisedResult(sendResponsePromise);
              }
              return true;
            };
          });
          const wrappedSendMessageCallback = ({
            reject,
            resolve
          }, reply) => {
            if (extensionAPIs.runtime.lastError) {
              if (extensionAPIs.runtime.lastError.message === CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE) {
                resolve();
              } else {
                reject(new Error(extensionAPIs.runtime.lastError.message));
              }
            } else if (reply && reply.__mozWebExtensionPolyfillReject__) {
              reject(new Error(reply.message));
            } else {
              resolve(reply);
            }
          };
          const wrappedSendMessage = (name, metadata, apiNamespaceObj, ...args) => {
            if (args.length < metadata.minArgs) {
              throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
            }
            if (args.length > metadata.maxArgs) {
              throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
            }
            return new Promise((resolve, reject) => {
              const wrappedCb = wrappedSendMessageCallback.bind(null, {
                resolve,
                reject
              });
              args.push(wrappedCb);
              apiNamespaceObj.sendMessage(...args);
            });
          };
          const staticWrappers = {
            devtools: {
              network: {
                onRequestFinished: wrapEvent(onRequestFinishedWrappers)
              }
            },
            runtime: {
              onMessage: wrapEvent(onMessageWrappers),
              onMessageExternal: wrapEvent(onMessageWrappers),
              sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
                minArgs: 1,
                maxArgs: 3
              })
            },
            tabs: {
              sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
                minArgs: 2,
                maxArgs: 3
              })
            }
          };
          const settingMetadata = {
            clear: {
              minArgs: 1,
              maxArgs: 1
            },
            get: {
              minArgs: 1,
              maxArgs: 1
            },
            set: {
              minArgs: 1,
              maxArgs: 1
            }
          };
          apiMetadata.privacy = {
            network: {
              "*": settingMetadata
            },
            services: {
              "*": settingMetadata
            },
            websites: {
              "*": settingMetadata
            }
          };
          return wrapObject(extensionAPIs, staticWrappers, apiMetadata);
        };
        module2.exports = wrapAPIs(chrome);
      } else {
        module2.exports = globalThis.browser;
      }
    });
  }
});

// src/background/index.ts
var import_webextension_polyfill = __toESM(require_browser_polyfill(), 1);

// src/background/collectionManager.ts
var COLLECTION_URL_PATTERN = /^https:\/\/(www\.)?moxfield\.com\/collection\/([a-zA-Z0-9_-]+)$/;
var MAX_COLLECTIONS = 20;
function validateUrl(url) {
  const match = url.match(COLLECTION_URL_PATTERN);
  if (!match) {
    return {
      valid: false,
      error: "Invalid URL format. Expected: https://moxfield.com/collection/{id}"
    };
  }
  const collectionId = match[2];
  return { valid: true, collectionId };
}
function addCollection(url, name, existingCollections) {
  const validation = validateUrl(url);
  if (!validation.valid) {
    return {
      success: false,
      error: validation.error
    };
  }
  const collectionId = validation.collectionId;
  const isDuplicate = existingCollections.some(
    (collection) => collection.id === collectionId
  );
  if (isDuplicate) {
    return { success: false, error: "Collection already tracked" };
  }
  if (existingCollections.length >= MAX_COLLECTIONS) {
    return { success: false, error: "Maximum collections reached" };
  }
  const newCollection = {
    id: collectionId,
    name,
    url,
    addedAt: Date.now(),
    lastFetched: null,
    fetchError: null
  };
  return { success: true, collection: newCollection };
}
function removeCollection(collectionId, existingCollections) {
  return existingCollections.filter(
    (collection) => collection.id !== collectionId
  );
}

// src/utils/cardNameNormalizer.ts
function normalize(cardName) {
  return cardName.trim().toLowerCase();
}

// src/utils/debugLogger.ts
var DEBUG_MODE_KEY = "debug_mode";
var MAX_LOG_ENTRIES = 500;
var DEBUG_LOG_KEY = "debug_log";
var debugEnabled = null;
var _browser = null;
var _browserChecked = false;
async function getBrowser() {
  if (_browserChecked) {
    return _browser;
  }
  _browserChecked = true;
  try {
    const mod = await Promise.resolve().then(() => __toESM(require_browser_polyfill(), 1));
    const b = mod.default ?? mod;
    if (b && b.storage && b.storage.local) {
      _browser = b;
      if (b.storage.onChanged) {
        b.storage.onChanged.addListener((changes) => {
          if (changes[DEBUG_MODE_KEY]) {
            debugEnabled = changes[DEBUG_MODE_KEY].newValue === true;
          }
        });
      }
    }
  } catch {
    _browser = null;
  }
  return _browser;
}
async function isDebugMode() {
  if (debugEnabled !== null) {
    return debugEnabled;
  }
  const b = await getBrowser();
  if (!b) {
    return false;
  }
  const result = await b.storage.local.get(DEBUG_MODE_KEY);
  debugEnabled = result[DEBUG_MODE_KEY] === true;
  return debugEnabled;
}
async function debugLog(area, level, message, details) {
  const enabled = await isDebugMode();
  if (level === "error") {
    console.error(`[MoxSync:${area}] ${message}`, details ?? "");
  }
  if (!enabled) {
    return;
  }
  if (level === "info") {
    console.log(`[MoxSync:${area}] ${message}`, details ?? "");
  } else if (level === "warn") {
    console.warn(`[MoxSync:${area}] ${message}`, details ?? "");
  }
  const entry = {
    timestamp: Date.now(),
    area,
    level,
    message,
    details: sanitizeDetails(details)
  };
  const b = await getBrowser();
  if (!b) {
    return;
  }
  try {
    const result = await b.storage.local.get(DEBUG_LOG_KEY);
    const logs = Array.isArray(result[DEBUG_LOG_KEY]) ? result[DEBUG_LOG_KEY] : [];
    logs.push(entry);
    if (logs.length > MAX_LOG_ENTRIES) {
      logs.splice(0, logs.length - MAX_LOG_ENTRIES);
    }
    await b.storage.local.set({ [DEBUG_LOG_KEY]: logs });
  } catch {
  }
}
function sanitizeDetails(details) {
  if (details === void 0 || details === null) {
    return void 0;
  }
  try {
    const json = JSON.stringify(details);
    if (json.length > 2048) {
      return JSON.parse(json.substring(0, 2048) + '..."');
    }
    return JSON.parse(json);
  } catch {
    return String(details);
  }
}

// src/utils/collectionFetcher.ts
var API_BASE = "https://api2.moxfield.com/v1/collections/search";
var TIMEOUT_MS = 3e4;
var PAGE_SIZE = 100;
async function fetchCollection(collectionId, onProgress) {
  const allCards = [];
  let pageNumber = 1;
  let totalPages = 1;
  let totalResults = 0;
  try {
    do {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), TIMEOUT_MS);
      try {
        const url = `${API_BASE}/${collectionId}?sortType=cardName&sortDirection=ascending&pageNumber=${pageNumber}&pageSize=${PAGE_SIZE}`;
        await debugLog("fetch", "info", `Fetching page ${pageNumber}/${totalPages}`, { collectionId, url });
        const response = await fetch(url, {
          signal: controller.signal,
          credentials: "include",
          headers: {
            "Accept": "application/json, text/plain, */*",
            "x-moxfield-version": "2026.08.19.1"
          }
        });
        if (!response.ok) {
          await debugLog("fetch", "error", `HTTP error fetching collection`, {
            collectionId,
            status: response.status,
            statusText: response.statusText,
            pageNumber
          });
          return {
            success: false,
            error: `HTTP ${response.status}: ${response.statusText}`
          };
        }
        let data;
        try {
          data = await response.json();
        } catch {
          await debugLog("fetch", "error", "Failed to parse JSON response", { collectionId, pageNumber });
          return { success: false, error: "Could not parse collection data" };
        }
        const parsed = parsePage(data);
        if (!parsed) {
          await debugLog("fetch", "error", "Unexpected response format", { collectionId, pageNumber });
          return { success: false, error: "Unexpected response format" };
        }
        allCards.push(...parsed.cards);
        totalPages = parsed.totalPages;
        totalResults = parsed.totalResults;
        if (onProgress) {
          onProgress({
            pageNumber,
            totalPages,
            cardsFetched: allCards.length,
            totalResults
          });
        }
        pageNumber++;
      } finally {
        clearTimeout(timeoutId);
      }
    } while (pageNumber <= totalPages);
    return { success: true, cards: allCards };
  } catch (error) {
    if (error instanceof DOMException && error.name === "AbortError") {
      await debugLog("fetch", "error", "Request timed out", { collectionId, pageNumber });
      return { success: false, error: "Request timed out after 30 seconds" };
    }
    const message = error instanceof Error ? error.message : "Unknown network error";
    await debugLog("fetch", "error", `Network error: ${message}`, { collectionId, pageNumber });
    return { success: false, error: message };
  }
}
function parsePage(data) {
  if (data === null || typeof data !== "object") {
    return null;
  }
  const response = data;
  const totalPages = typeof response["totalPages"] === "number" ? response["totalPages"] : 0;
  const totalResults = typeof response["totalResults"] === "number" ? response["totalResults"] : 0;
  const dataArray = response["data"];
  if (!Array.isArray(dataArray)) {
    return null;
  }
  const cards = [];
  for (const entry of dataArray) {
    if (entry === null || typeof entry !== "object") {
      continue;
    }
    const entryObj = entry;
    const quantity = typeof entryObj["quantity"] === "number" ? entryObj["quantity"] : 0;
    const card = entryObj["card"];
    if (card === null || typeof card !== "object") {
      continue;
    }
    const cardObj = card;
    const name = typeof cardObj["name"] === "string" ? cardObj["name"] : "";
    const setName = typeof cardObj["set_name"] === "string" ? cardObj["set_name"] : "";
    const cn = typeof cardObj["cn"] === "string" ? cardObj["cn"] : "";
    const finish = typeof entryObj["finish"] === "string" ? entryObj["finish"] : "nonFoil";
    if (name && quantity > 0) {
      cards.push({ name, quantity, setName, collectorNumber: cn, finish });
    }
  }
  return { cards, totalPages, totalResults };
}

// src/background/index.ts
var STORAGE_KEY_COLLECTIONS = "tracked_collections";
var STORAGE_KEY_CARDS_PREFIX = "collection_cards_";
async function getTrackedCollections() {
  const result = await import_webextension_polyfill.default.storage.local.get(STORAGE_KEY_COLLECTIONS);
  const stored = result[STORAGE_KEY_COLLECTIONS];
  if (Array.isArray(stored)) {
    return stored;
  }
  return [];
}
async function setTrackedCollections(collections) {
  await debugLog("storage", "info", `Writing ${collections.length} collections to storage`);
  await import_webextension_polyfill.default.storage.local.set({
    [STORAGE_KEY_COLLECTIONS]: collections
  });
}
async function fetchCollectionViaTab(collectionId) {
  await debugLog("fetch", "info", `Starting fetch for collection ${collectionId}`);
  const tabs = await import_webextension_polyfill.default.tabs.query({ url: "*://*.moxfield.com/*" });
  const tab = tabs.find((t) => t.id !== void 0);
  if (!tab || tab.id === void 0) {
    await debugLog("fetch", "warn", "No moxfield tab found, falling back to direct fetch", { collectionId });
    return fetchCollection(collectionId);
  }
  try {
    await debugLog("fetch", "info", `Delegating fetch to tab ${tab.id}`, { collectionId, tabUrl: tab.url });
    const response = await import_webextension_polyfill.default.tabs.sendMessage(tab.id, {
      type: "FETCH_COLLECTION",
      collectionId
    });
    const result = response;
    if (!result.success) {
      await debugLog("fetch", "warn", `Content script fetch returned error: ${result.error}, retrying from background`, { collectionId });
      return fetchCollection(collectionId);
    }
    return result;
  } catch (err) {
    await debugLog("fetch", "warn", "Content script fetch failed, falling back to direct fetch", {
      collectionId,
      error: err instanceof Error ? err.message : String(err)
    });
    return fetchCollection(collectionId);
  }
}
async function fetchAndStoreCards(collection) {
  const result = await fetchCollectionViaTab(collection.id);
  if (result.success) {
    const now = Date.now();
    const storedCards = result.cards.map((card) => ({
      name: card.name,
      normalizedName: normalize(card.name),
      quantity: card.quantity,
      setName: card.setName,
      collectorNumber: card.collectorNumber,
      finish: card.finish
    }));
    await debugLog("fetch", "info", `Fetched ${storedCards.length} cards for "${collection.name}"`, {
      collectionId: collection.id
    });
    const cardData = {
      collectionId: collection.id,
      cards: storedCards,
      fetchedAt: now
    };
    await debugLog("storage", "info", `Storing ${storedCards.length} cards for collection ${collection.id}`);
    await import_webextension_polyfill.default.storage.local.set({
      [`${STORAGE_KEY_CARDS_PREFIX}${collection.id}`]: cardData
    });
    return {
      ...collection,
      lastFetched: now,
      fetchError: null
    };
  } else {
    await debugLog("fetch", "error", `Fetch failed for "${collection.name}": ${result.error}`, {
      collectionId: collection.id
    });
    return {
      ...collection,
      fetchError: result.error
    };
  }
}
async function handleAddCollection(url, name) {
  await debugLog("collection", "info", `Adding collection "${name}"`, { url });
  const collections = await getTrackedCollections();
  const result = addCollection(url, name, collections);
  if (!result.success) {
    await debugLog("collection", "error", `Failed to add collection "${name}": ${result.error}`, { url });
    return result;
  }
  const updatedCollections = [...collections, result.collection];
  await setTrackedCollections(updatedCollections);
  const updatedCollection = await fetchAndStoreCards(result.collection);
  const finalCollections = updatedCollections.map(
    (c) => c.id === updatedCollection.id ? updatedCollection : c
  );
  await setTrackedCollections(finalCollections);
  return { success: true, collection: updatedCollection };
}
async function handleRemoveCollection(collectionId) {
  await debugLog("collection", "info", `Removing collection ${collectionId}`);
  const collections = await getTrackedCollections();
  const updatedCollections = removeCollection(collectionId, collections);
  await setTrackedCollections(updatedCollections);
  await debugLog("storage", "info", `Removing card data for collection ${collectionId}`);
  await import_webextension_polyfill.default.storage.local.remove(
    `${STORAGE_KEY_CARDS_PREFIX}${collectionId}`
  );
  return { success: true };
}
async function handleRefreshAll() {
  const collections = await getTrackedCollections();
  if (collections.length === 0) {
    return { success: true, results: [] };
  }
  const fetchPromises = collections.map(async (collection) => {
    const updated = await fetchAndStoreCards(collection);
    return {
      updated,
      result: {
        collectionId: collection.id,
        success: updated.fetchError === null,
        ...updated.fetchError !== null ? { error: updated.fetchError } : {}
      }
    };
  });
  const outcomes = await Promise.allSettled(fetchPromises);
  const results = [];
  const updatedCollections = [...collections];
  for (let i = 0; i < outcomes.length; i++) {
    const outcome = outcomes[i];
    if (outcome.status === "fulfilled") {
      results.push(outcome.value.result);
      const idx = updatedCollections.findIndex(
        (c) => c.id === outcome.value.updated.id
      );
      if (idx !== -1) {
        updatedCollections[idx] = outcome.value.updated;
      }
    } else {
      await debugLog("fetch", "error", `Unexpected error refreshing collection ${collections[i].id}`, {
        reason: outcome.reason instanceof Error ? outcome.reason.message : String(outcome.reason)
      });
      results.push({
        collectionId: collections[i].id,
        success: false,
        error: "Unexpected error during refresh"
      });
    }
  }
  await setTrackedCollections(updatedCollections);
  return { success: true, results };
}
async function handleGetCollections() {
  const collections = await getTrackedCollections();
  return { collections };
}
var fetchProgressMap = /* @__PURE__ */ new Map();
import_webextension_polyfill.default.runtime.onMessage.addListener(
  (message) => {
    const msg = message;
    switch (msg.type) {
      case "ADD_COLLECTION":
        void debugLog("general", "info", `Message received: ADD_COLLECTION`, { url: msg.url, name: msg.name });
        return handleAddCollection(msg.url, msg.name);
      case "REMOVE_COLLECTION":
        void debugLog("general", "info", `Message received: REMOVE_COLLECTION`, { collectionId: msg.collectionId });
        return handleRemoveCollection(msg.collectionId);
      case "REFRESH_ALL":
        void debugLog("general", "info", "Message received: REFRESH_ALL");
        return handleRefreshAll();
      case "GET_COLLECTIONS":
        void debugLog("general", "info", "Message received: GET_COLLECTIONS");
        return handleGetCollections();
      case "FETCH_PROGRESS": {
        const progress = msg.progress;
        const collectionId = msg.collectionId;
        if (progress && collectionId) {
          fetchProgressMap.set(collectionId, progress);
        }
        return Promise.resolve({ received: true });
      }
      case "GET_FETCH_PROGRESS": {
        const progressObj = {};
        for (const [id, p] of fetchProgressMap) {
          progressObj[id] = p;
        }
        return Promise.resolve({ progress: progressObj });
      }
      case "CLEAR_FETCH_PROGRESS": {
        fetchProgressMap.clear();
        return Promise.resolve({ cleared: true });
      }
      default:
        return void 0;
    }
  }
);
