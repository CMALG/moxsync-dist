"use strict";
(() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __commonJS = (cb, mod) => function __require() {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));

  // node_modules/webextension-polyfill/dist/browser-polyfill.js
  var require_browser_polyfill = __commonJS({
    "node_modules/webextension-polyfill/dist/browser-polyfill.js"(exports, module) {
      (function(global, factory) {
        if (typeof define === "function" && define.amd) {
          define("webextension-polyfill", ["module"], factory);
        } else if (typeof exports !== "undefined") {
          factory(module);
        } else {
          var mod = {
            exports: {}
          };
          factory(mod);
          global.browser = mod.exports;
        }
      })(typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : exports, function(module2) {
        "use strict";
        if (!(globalThis.chrome && globalThis.chrome.runtime && globalThis.chrome.runtime.id)) {
          throw new Error("This script should only be loaded in a browser extension.");
        }
        if (!(globalThis.browser && globalThis.browser.runtime && globalThis.browser.runtime.id)) {
          const CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE = "The message port closed before a response was received.";
          const wrapAPIs = (extensionAPIs) => {
            const apiMetadata = {
              "alarms": {
                "clear": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "clearAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "get": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "bookmarks": {
                "create": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getChildren": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getRecent": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getSubTree": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTree": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "move": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeTree": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "browserAction": {
                "disable": {
                  "minArgs": 0,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "enable": {
                  "minArgs": 0,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "getBadgeBackgroundColor": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getBadgeText": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getPopup": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTitle": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "openPopup": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "setBadgeBackgroundColor": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setBadgeText": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setIcon": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "setPopup": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setTitle": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "browsingData": {
                "remove": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "removeCache": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeCookies": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeDownloads": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeFormData": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeHistory": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeLocalStorage": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removePasswords": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removePluginData": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "settings": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "commands": {
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "contextMenus": {
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "cookies": {
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAllCookieStores": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "set": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "devtools": {
                "inspectedWindow": {
                  "eval": {
                    "minArgs": 1,
                    "maxArgs": 2,
                    "singleCallbackArg": false
                  }
                },
                "panels": {
                  "create": {
                    "minArgs": 3,
                    "maxArgs": 3,
                    "singleCallbackArg": true
                  },
                  "elements": {
                    "createSidebarPane": {
                      "minArgs": 1,
                      "maxArgs": 1
                    }
                  }
                }
              },
              "downloads": {
                "cancel": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "download": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "erase": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getFileIcon": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "open": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "pause": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeFile": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "resume": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "show": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "extension": {
                "isAllowedFileSchemeAccess": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "isAllowedIncognitoAccess": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "history": {
                "addUrl": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "deleteAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "deleteRange": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "deleteUrl": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getVisits": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "i18n": {
                "detectLanguage": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAcceptLanguages": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "identity": {
                "launchWebAuthFlow": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "idle": {
                "queryState": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "management": {
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getSelf": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "setEnabled": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "uninstallSelf": {
                  "minArgs": 0,
                  "maxArgs": 1
                }
              },
              "notifications": {
                "clear": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "create": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getPermissionLevel": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "pageAction": {
                "getPopup": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTitle": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "hide": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setIcon": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "setPopup": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setTitle": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "show": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "permissions": {
                "contains": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "request": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "runtime": {
                "getBackgroundPage": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getPlatformInfo": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "openOptionsPage": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "requestUpdateCheck": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "sendMessage": {
                  "minArgs": 1,
                  "maxArgs": 3
                },
                "sendNativeMessage": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "setUninstallURL": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "sessions": {
                "getDevices": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getRecentlyClosed": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "restore": {
                  "minArgs": 0,
                  "maxArgs": 1
                }
              },
              "storage": {
                "local": {
                  "clear": {
                    "minArgs": 0,
                    "maxArgs": 0
                  },
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "remove": {
                    "minArgs": 1,
                    "maxArgs": 1
                  },
                  "set": {
                    "minArgs": 1,
                    "maxArgs": 1
                  }
                },
                "managed": {
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  }
                },
                "sync": {
                  "clear": {
                    "minArgs": 0,
                    "maxArgs": 0
                  },
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "remove": {
                    "minArgs": 1,
                    "maxArgs": 1
                  },
                  "set": {
                    "minArgs": 1,
                    "maxArgs": 1
                  }
                }
              },
              "tabs": {
                "captureVisibleTab": {
                  "minArgs": 0,
                  "maxArgs": 2
                },
                "create": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "detectLanguage": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "discard": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "duplicate": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "executeScript": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getCurrent": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getZoom": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getZoomSettings": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "goBack": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "goForward": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "highlight": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "insertCSS": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "move": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "query": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "reload": {
                  "minArgs": 0,
                  "maxArgs": 2
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeCSS": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "sendMessage": {
                  "minArgs": 2,
                  "maxArgs": 3
                },
                "setZoom": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "setZoomSettings": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "update": {
                  "minArgs": 1,
                  "maxArgs": 2
                }
              },
              "topSites": {
                "get": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "webNavigation": {
                "getAllFrames": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getFrame": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "webRequest": {
                "handlerBehaviorChanged": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "windows": {
                "create": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getCurrent": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getLastFocused": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              }
            };
            if (Object.keys(apiMetadata).length === 0) {
              throw new Error("api-metadata.json has not been included in browser-polyfill");
            }
            class DefaultWeakMap extends WeakMap {
              constructor(createItem, items = void 0) {
                super(items);
                this.createItem = createItem;
              }
              get(key) {
                if (!this.has(key)) {
                  this.set(key, this.createItem(key));
                }
                return super.get(key);
              }
            }
            const isThenable = (value) => {
              return value && typeof value === "object" && typeof value.then === "function";
            };
            const makeCallback = (promise, metadata) => {
              return (...callbackArgs) => {
                if (extensionAPIs.runtime.lastError) {
                  promise.reject(new Error(extensionAPIs.runtime.lastError.message));
                } else if (metadata.singleCallbackArg || callbackArgs.length <= 1 && metadata.singleCallbackArg !== false) {
                  promise.resolve(callbackArgs[0]);
                } else {
                  promise.resolve(callbackArgs);
                }
              };
            };
            const pluralizeArguments = (numArgs) => numArgs == 1 ? "argument" : "arguments";
            const wrapAsyncFunction = (name, metadata) => {
              return function asyncFunctionWrapper(target, ...args) {
                if (args.length < metadata.minArgs) {
                  throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
                }
                if (args.length > metadata.maxArgs) {
                  throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
                }
                return new Promise((resolve, reject) => {
                  if (metadata.fallbackToNoCallback) {
                    try {
                      target[name](...args, makeCallback({
                        resolve,
                        reject
                      }, metadata));
                    } catch (cbError) {
                      console.warn(`${name} API method doesn't seem to support the callback parameter, falling back to call it without a callback: `, cbError);
                      target[name](...args);
                      metadata.fallbackToNoCallback = false;
                      metadata.noCallback = true;
                      resolve();
                    }
                  } else if (metadata.noCallback) {
                    target[name](...args);
                    resolve();
                  } else {
                    target[name](...args, makeCallback({
                      resolve,
                      reject
                    }, metadata));
                  }
                });
              };
            };
            const wrapMethod = (target, method, wrapper) => {
              return new Proxy(method, {
                apply(targetMethod, thisObj, args) {
                  return wrapper.call(thisObj, target, ...args);
                }
              });
            };
            let hasOwnProperty = Function.call.bind(Object.prototype.hasOwnProperty);
            const wrapObject = (target, wrappers = {}, metadata = {}) => {
              let cache = /* @__PURE__ */ Object.create(null);
              let handlers = {
                has(proxyTarget2, prop) {
                  return prop in target || prop in cache;
                },
                get(proxyTarget2, prop, receiver) {
                  if (prop in cache) {
                    return cache[prop];
                  }
                  if (!(prop in target)) {
                    return void 0;
                  }
                  let value = target[prop];
                  if (typeof value === "function") {
                    if (typeof wrappers[prop] === "function") {
                      value = wrapMethod(target, target[prop], wrappers[prop]);
                    } else if (hasOwnProperty(metadata, prop)) {
                      let wrapper = wrapAsyncFunction(prop, metadata[prop]);
                      value = wrapMethod(target, target[prop], wrapper);
                    } else {
                      value = value.bind(target);
                    }
                  } else if (typeof value === "object" && value !== null && (hasOwnProperty(wrappers, prop) || hasOwnProperty(metadata, prop))) {
                    value = wrapObject(value, wrappers[prop], metadata[prop]);
                  } else if (hasOwnProperty(metadata, "*")) {
                    value = wrapObject(value, wrappers[prop], metadata["*"]);
                  } else {
                    Object.defineProperty(cache, prop, {
                      configurable: true,
                      enumerable: true,
                      get() {
                        return target[prop];
                      },
                      set(value2) {
                        target[prop] = value2;
                      }
                    });
                    return value;
                  }
                  cache[prop] = value;
                  return value;
                },
                set(proxyTarget2, prop, value, receiver) {
                  if (prop in cache) {
                    cache[prop] = value;
                  } else {
                    target[prop] = value;
                  }
                  return true;
                },
                defineProperty(proxyTarget2, prop, desc) {
                  return Reflect.defineProperty(cache, prop, desc);
                },
                deleteProperty(proxyTarget2, prop) {
                  return Reflect.deleteProperty(cache, prop);
                }
              };
              let proxyTarget = Object.create(target);
              return new Proxy(proxyTarget, handlers);
            };
            const wrapEvent = (wrapperMap) => ({
              addListener(target, listener, ...args) {
                target.addListener(wrapperMap.get(listener), ...args);
              },
              hasListener(target, listener) {
                return target.hasListener(wrapperMap.get(listener));
              },
              removeListener(target, listener) {
                target.removeListener(wrapperMap.get(listener));
              }
            });
            const onRequestFinishedWrappers = new DefaultWeakMap((listener) => {
              if (typeof listener !== "function") {
                return listener;
              }
              return function onRequestFinished(req) {
                const wrappedReq = wrapObject(req, {}, {
                  getContent: {
                    minArgs: 0,
                    maxArgs: 0
                  }
                });
                listener(wrappedReq);
              };
            });
            const onMessageWrappers = new DefaultWeakMap((listener) => {
              if (typeof listener !== "function") {
                return listener;
              }
              return function onMessage(message, sender, sendResponse) {
                let didCallSendResponse = false;
                let wrappedSendResponse;
                let sendResponsePromise = new Promise((resolve) => {
                  wrappedSendResponse = function(response) {
                    didCallSendResponse = true;
                    resolve(response);
                  };
                });
                let result;
                try {
                  result = listener(message, sender, wrappedSendResponse);
                } catch (err) {
                  result = Promise.reject(err);
                }
                const isResultThenable = result !== true && isThenable(result);
                if (result !== true && !isResultThenable && !didCallSendResponse) {
                  return false;
                }
                const sendPromisedResult = (promise) => {
                  promise.then((msg) => {
                    sendResponse(msg);
                  }, (error) => {
                    let message2;
                    if (error && (error instanceof Error || typeof error.message === "string")) {
                      message2 = error.message;
                    } else {
                      message2 = "An unexpected error occurred";
                    }
                    sendResponse({
                      __mozWebExtensionPolyfillReject__: true,
                      message: message2
                    });
                  }).catch((err) => {
                    console.error("Failed to send onMessage rejected reply", err);
                  });
                };
                if (isResultThenable) {
                  sendPromisedResult(result);
                } else {
                  sendPromisedResult(sendResponsePromise);
                }
                return true;
              };
            });
            const wrappedSendMessageCallback = ({
              reject,
              resolve
            }, reply) => {
              if (extensionAPIs.runtime.lastError) {
                if (extensionAPIs.runtime.lastError.message === CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE) {
                  resolve();
                } else {
                  reject(new Error(extensionAPIs.runtime.lastError.message));
                }
              } else if (reply && reply.__mozWebExtensionPolyfillReject__) {
                reject(new Error(reply.message));
              } else {
                resolve(reply);
              }
            };
            const wrappedSendMessage = (name, metadata, apiNamespaceObj, ...args) => {
              if (args.length < metadata.minArgs) {
                throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
              }
              if (args.length > metadata.maxArgs) {
                throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
              }
              return new Promise((resolve, reject) => {
                const wrappedCb = wrappedSendMessageCallback.bind(null, {
                  resolve,
                  reject
                });
                args.push(wrappedCb);
                apiNamespaceObj.sendMessage(...args);
              });
            };
            const staticWrappers = {
              devtools: {
                network: {
                  onRequestFinished: wrapEvent(onRequestFinishedWrappers)
                }
              },
              runtime: {
                onMessage: wrapEvent(onMessageWrappers),
                onMessageExternal: wrapEvent(onMessageWrappers),
                sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
                  minArgs: 1,
                  maxArgs: 3
                })
              },
              tabs: {
                sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
                  minArgs: 2,
                  maxArgs: 3
                })
              }
            };
            const settingMetadata = {
              clear: {
                minArgs: 1,
                maxArgs: 1
              },
              get: {
                minArgs: 1,
                maxArgs: 1
              },
              set: {
                minArgs: 1,
                maxArgs: 1
              }
            };
            apiMetadata.privacy = {
              network: {
                "*": settingMetadata
              },
              services: {
                "*": settingMetadata
              },
              websites: {
                "*": settingMetadata
              }
            };
            return wrapObject(extensionAPIs, staticWrappers, apiMetadata);
          };
          module2.exports = wrapAPIs(chrome);
        } else {
          module2.exports = globalThis.browser;
        }
      });
    }
  });

  // src/popup/popup.ts
  var import_webextension_polyfill = __toESM(require_browser_polyfill(), 1);

  // src/popup/renderCollections.ts
  function truncateUrl(url, maxLength = 40) {
    if (url.length <= maxLength) {
      return url;
    }
    return url.substring(0, maxLength - 3) + "...";
  }
  function formatTimestamp(ts) {
    if (ts === null) {
      return "Never";
    }
    const now = Date.now();
    const diffMs = now - ts;
    const diffSeconds = Math.floor(diffMs / 1e3);
    const diffMinutes = Math.floor(diffSeconds / 60);
    const diffHours = Math.floor(diffMinutes / 60);
    const diffDays = Math.floor(diffHours / 24);
    if (diffSeconds < 60) {
      return "Just now";
    } else if (diffMinutes < 60) {
      return `${diffMinutes} minute${diffMinutes === 1 ? "" : "s"} ago`;
    } else if (diffHours < 24) {
      return `${diffHours} hour${diffHours === 1 ? "" : "s"} ago`;
    } else if (diffDays < 30) {
      return `${diffDays} day${diffDays === 1 ? "" : "s"} ago`;
    } else {
      const date = new Date(ts);
      return date.toLocaleDateString();
    }
  }
  async function renderCollections(collections, options) {
    const { collectionListEl, emptyStateEl, refreshAllBtn: refreshAllBtn2, getCardCount: getCardCount2, onRemove, onOpen } = options;
    if (collections.length === 0) {
      emptyStateEl.classList.remove("hidden");
      collectionListEl.innerHTML = "";
      refreshAllBtn2.disabled = true;
      return;
    }
    emptyStateEl.classList.add("hidden");
    refreshAllBtn2.disabled = false;
    const cardCounts = await Promise.all(
      collections.map((c) => getCardCount2(c.id))
    );
    collectionListEl.innerHTML = "";
    collections.forEach((collection, index) => {
      const item = document.createElement("div");
      item.className = "collection-item";
      item.dataset.collectionId = collection.id;
      const info = document.createElement("div");
      info.className = "collection-info";
      const name = document.createElement("div");
      name.className = "collection-name";
      name.textContent = collection.name;
      name.title = collection.name;
      const urlRow = document.createElement("div");
      urlRow.className = "collection-url-row";
      const url = document.createElement("span");
      url.className = "collection-url";
      url.textContent = truncateUrl(collection.url);
      url.title = collection.url;
      urlRow.appendChild(url);
      const meta = document.createElement("div");
      meta.className = "collection-meta";
      const lastFetched = document.createElement("span");
      lastFetched.textContent = `Fetched: ${formatTimestamp(collection.lastFetched)}`;
      const cardCount = document.createElement("span");
      const count = cardCounts[index];
      cardCount.textContent = `Cards: ${count > 0 ? count : "N/A"}`;
      meta.appendChild(lastFetched);
      meta.appendChild(cardCount);
      info.appendChild(name);
      info.appendChild(urlRow);
      info.appendChild(meta);
      if (collection.fetchError) {
        const errorEl = document.createElement("div");
        errorEl.className = "collection-error";
        errorEl.textContent = collection.fetchError;
        info.appendChild(errorEl);
      }
      const actions = document.createElement("div");
      actions.className = "collection-actions";
      const removeBtn = document.createElement("button");
      removeBtn.className = "btn-remove";
      removeBtn.textContent = "Remove";
      removeBtn.addEventListener("click", () => onRemove(collection.id, collection.name));
      const openBtn = document.createElement("button");
      openBtn.className = "btn-open";
      openBtn.textContent = "Open";
      openBtn.title = "Open collection in a new tab";
      openBtn.addEventListener("click", () => onOpen(collection.url));
      actions.appendChild(removeBtn);
      actions.appendChild(openBtn);
      item.appendChild(info);
      item.appendChild(actions);
      collectionListEl.appendChild(item);
    });
  }

  // src/utils/debugLogger.ts
  var DEBUG_MODE_KEY = "debug_mode";
  var DEBUG_LOG_KEY = "debug_log";
  var debugEnabled = null;
  var _browser = null;
  var _browserChecked = false;
  async function getBrowser() {
    if (_browserChecked) {
      return _browser;
    }
    _browserChecked = true;
    try {
      const mod = await Promise.resolve().then(() => __toESM(require_browser_polyfill(), 1));
      const b = mod.default ?? mod;
      if (b && b.storage && b.storage.local) {
        _browser = b;
        if (b.storage.onChanged) {
          b.storage.onChanged.addListener((changes) => {
            if (changes[DEBUG_MODE_KEY]) {
              debugEnabled = changes[DEBUG_MODE_KEY].newValue === true;
            }
          });
        }
      }
    } catch {
      _browser = null;
    }
    return _browser;
  }
  async function isDebugMode() {
    if (debugEnabled !== null) {
      return debugEnabled;
    }
    const b = await getBrowser();
    if (!b) {
      return false;
    }
    const result = await b.storage.local.get(DEBUG_MODE_KEY);
    debugEnabled = result[DEBUG_MODE_KEY] === true;
    return debugEnabled;
  }
  async function setDebugMode(enabled) {
    debugEnabled = enabled;
    const b = await getBrowser();
    if (!b) {
      return;
    }
    await b.storage.local.set({ [DEBUG_MODE_KEY]: enabled });
    if (!enabled) {
      await b.storage.local.remove(DEBUG_LOG_KEY);
    }
  }
  async function getDebugLogs() {
    const b = await getBrowser();
    if (!b) {
      return [];
    }
    const result = await b.storage.local.get(DEBUG_LOG_KEY);
    return Array.isArray(result[DEBUG_LOG_KEY]) ? result[DEBUG_LOG_KEY] : [];
  }
  async function clearDebugLogs() {
    const b = await getBrowser();
    if (!b) {
      return;
    }
    await b.storage.local.remove(DEBUG_LOG_KEY);
  }

  // src/popup/popup.ts
  var addForm = document.getElementById(
    "add-collection-form"
  );
  var urlInput = document.getElementById("url-input");
  var nameInput = document.getElementById("name-input");
  var statusMessage = document.getElementById(
    "status-message"
  );
  var collectionList = document.getElementById(
    "collection-list"
  );
  var emptyState = document.getElementById("empty-state");
  var refreshAllBtn = document.getElementById(
    "refresh-all-btn"
  );
  var debugToggle = document.getElementById(
    "debug-toggle"
  );
  var debugPanel = document.getElementById("debug-panel");
  var debugLogEl = document.getElementById("debug-log");
  var debugClearBtn = document.getElementById(
    "debug-clear-btn"
  );
  function showStatus(message, type) {
    statusMessage.textContent = message;
    statusMessage.className = `status-message ${type}`;
  }
  function hideStatus() {
    statusMessage.className = "status-message hidden";
    statusMessage.textContent = "";
  }
  var progressInterval = null;
  function startProgressPolling() {
    stopProgressPolling();
    progressInterval = setInterval(async () => {
      try {
        const response = await import_webextension_polyfill.default.runtime.sendMessage({
          type: "GET_FETCH_PROGRESS"
        });
        if (response && response.progress) {
          const entries = Object.values(response.progress);
          if (entries.length > 0) {
            const latest = entries[entries.length - 1];
            showStatus(
              `Fetching... ${latest.cardsFetched} / ${latest.totalResults} cards (page ${latest.pageNumber}/${latest.totalPages})`,
              "info"
            );
          }
        }
      } catch {
      }
    }, 500);
  }
  function stopProgressPolling() {
    if (progressInterval !== null) {
      clearInterval(progressInterval);
      progressInterval = null;
    }
  }
  async function getCardCount(collectionId) {
    const key = `collection_cards_${collectionId}`;
    const result = await import_webextension_polyfill.default.storage.local.get(key);
    const data = result[key];
    if (data && Array.isArray(data.cards)) {
      return data.cards.length;
    }
    return 0;
  }
  async function renderCollectionList(collections) {
    await renderCollections(collections, {
      collectionListEl: collectionList,
      emptyStateEl: emptyState,
      refreshAllBtn,
      getCardCount,
      onRemove: handleRemove,
      onOpen: handleOpen
    });
  }
  async function loadAndRenderCollections() {
    const response = await import_webextension_polyfill.default.runtime.sendMessage({
      type: "GET_COLLECTIONS"
    });
    await renderCollectionList(response.collections);
  }
  async function handleAddSubmit(event) {
    event.preventDefault();
    const url = urlInput.value.trim();
    const name = nameInput.value.trim();
    if (!url) {
      showStatus("Please enter a collection URL.", "error");
      return;
    }
    if (!name) {
      showStatus("Name is required.", "error");
      return;
    }
    hideStatus();
    showStatus("Fetching collection...", "info");
    startProgressPolling();
    const response = await import_webextension_polyfill.default.runtime.sendMessage({
      type: "ADD_COLLECTION",
      url,
      name
    });
    stopProgressPolling();
    import_webextension_polyfill.default.runtime.sendMessage({ type: "CLEAR_FETCH_PROGRESS" }).catch(() => {
    });
    if (response.success) {
      urlInput.value = "";
      nameInput.value = "";
      showStatus("Collection added successfully!", "success");
      setTimeout(hideStatus, 3e3);
      await loadAndRenderCollections();
    } else {
      showStatus(response.error, "error");
    }
  }
  async function handleRemove(collectionId, collectionName) {
    const confirmed = window.confirm(
      `Remove "${collectionName}" from tracking? This cannot be undone.`
    );
    if (!confirmed) {
      return;
    }
    await import_webextension_polyfill.default.runtime.sendMessage({
      type: "REMOVE_COLLECTION",
      collectionId
    });
    await loadAndRenderCollections();
  }
  async function handleOpen(url) {
    await import_webextension_polyfill.default.tabs.create({ url });
  }
  async function handleRefreshAll() {
    const items = collectionList.querySelectorAll(".collection-item");
    items.forEach((item) => item.classList.add("loading"));
    refreshAllBtn.disabled = true;
    showStatus("Refreshing collections...", "info");
    startProgressPolling();
    const response = await import_webextension_polyfill.default.runtime.sendMessage({
      type: "REFRESH_ALL"
    });
    stopProgressPolling();
    import_webextension_polyfill.default.runtime.sendMessage({ type: "CLEAR_FETCH_PROGRESS" }).catch(() => {
    });
    if (response.success) {
      const errors = response.results.filter((r) => !r.success);
      if (errors.length > 0) {
        const failedCount = errors.length;
        showStatus(
          `Refresh completed. ${failedCount} collection${failedCount === 1 ? "" : "s"} failed to update.`,
          "info"
        );
      } else {
        showStatus("All collections refreshed!", "success");
        setTimeout(hideStatus, 3e3);
      }
    } else {
      showStatus("Failed to refresh collections.", "error");
    }
    await loadAndRenderCollections();
  }
  function formatDebugTime(ts) {
    const d = new Date(ts);
    return d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" });
  }
  async function renderDebugLog() {
    const logs = await getDebugLogs();
    if (logs.length === 0) {
      debugLogEl.innerHTML = '<div class="debug-empty">No log entries yet. Perform actions to see debug output.</div>';
      return;
    }
    debugLogEl.innerHTML = "";
    for (const entry of logs) {
      const el = document.createElement("div");
      el.className = `debug-entry level-${entry.level}`;
      const time = document.createElement("span");
      time.className = "time";
      time.textContent = formatDebugTime(entry.timestamp);
      const area = document.createElement("span");
      area.className = "area";
      area.textContent = ` [${entry.area}] `;
      el.appendChild(time);
      el.appendChild(area);
      el.appendChild(document.createTextNode(entry.message));
      if (entry.details) {
        const details = document.createElement("div");
        details.style.cssText = "margin-left: 16px; color: #9ca3af; font-size: 10px;";
        details.textContent = typeof entry.details === "string" ? entry.details : JSON.stringify(entry.details);
        el.appendChild(details);
      }
      debugLogEl.appendChild(el);
    }
    debugLogEl.scrollTop = debugLogEl.scrollHeight;
  }
  var debugPollInterval = null;
  function startDebugPolling() {
    stopDebugPolling();
    void renderDebugLog();
    debugPollInterval = setInterval(() => void renderDebugLog(), 2e3);
  }
  function stopDebugPolling() {
    if (debugPollInterval !== null) {
      clearInterval(debugPollInterval);
      debugPollInterval = null;
    }
  }
  document.addEventListener("DOMContentLoaded", async () => {
    await loadAndRenderCollections();
    try {
      const progressResponse = await import_webextension_polyfill.default.runtime.sendMessage({
        type: "GET_FETCH_PROGRESS"
      });
      if (progressResponse && progressResponse.progress) {
        const entries = Object.values(progressResponse.progress);
        if (entries.length > 0) {
          const latest = entries[entries.length - 1];
          showStatus(
            `Fetching... ${latest.cardsFetched} / ${latest.totalResults} cards (page ${latest.pageNumber}/${latest.totalPages})`,
            "info"
          );
          startProgressPolling();
        }
      }
    } catch {
    }
    addForm.addEventListener("submit", handleAddSubmit);
    refreshAllBtn.addEventListener("click", handleRefreshAll);
    const debugEnabled2 = await isDebugMode();
    debugToggle.checked = debugEnabled2;
    if (debugEnabled2) {
      debugPanel.classList.remove("hidden");
      startDebugPolling();
    }
    debugToggle.addEventListener("change", async () => {
      const enabled = debugToggle.checked;
      await setDebugMode(enabled);
      if (enabled) {
        debugPanel.classList.remove("hidden");
        startDebugPolling();
      } else {
        debugPanel.classList.add("hidden");
        stopDebugPolling();
        debugLogEl.innerHTML = "";
      }
    });
    debugClearBtn.addEventListener("click", async () => {
      await clearDebugLogs();
      await renderDebugLog();
    });
  });
})();
